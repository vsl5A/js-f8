// import React, { useState, useEffect } from 'react';
// import { Link, useParams } from 'react-router-dom';
// // import axios from 'axios';

// const ViewProfile = () => {
   

//   return (
//     <div>
//       <h1>User Profile</h1>
//     <div class="table-wrap">
//       <table>
//         <tr>
//           <td>Name:</td>
//           <td>John Doe</td>
//         </tr>
//         <tr>
//           <td>Age:</td>
//           <td>30</td>
//         </tr>
//         <tr>
//           <td>Gender:</td>
//           <td>Male</td>
//         </tr>
//         <tr>
//           <td>Email:</td>
//           <td>john.doe@example.com</td>
//         </tr>
//         <tr>
//           <td>Phone:</td>
//           <td>123-456-7890</td>
//         </tr>
//       </table>
//     </div>
     
//     </div>
//   );
// };

// export default ViewProfile;


import { Grid, FormControl, TextField, Autocomplete } from '@mui/material';
import React, { useState } from 'react';
import axios from 'axios';
import { GreenButton, RedButton } from '../button-theme/ButtonTheme';
import ConfirmDialog from '../ConfirmDialog';
import { useNavigate } from 'react-router-dom';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";


const ViewProfile = () => {
  const [Profile, setProfile] = useState({
    name: 'John Doe',
    Address: 'abcxxxxxxx',
    birthDate: '12/03/2021',
    email: 'john.doe@example.com',
    numberphone: '123-456-7890'
    
  });
  // function handleDateSelect(date) {
  //   console.log(date);
  //   return date;
  // } 
    

     


 
  

  return (
    <div>
      <div className='pageTitle'><h2>ViewProfile </h2></div>
      <table style={{width:"100%",margin:"20px 0"}}>
      <tbody>
        <tr>
          <td>Name:</td>
          <td>{Profile.name}</td>
        </tr>
        <tr>
          <td>Email:</td>
          <td>{Profile.email}</td>
        </tr>
        <tr>
          <td>Address:</td>
          <td>{Profile.Address}</td>
        </tr>
        <tr>
          <td>Phone:</td>
          <td>{Profile.numberphone}</td>
        </tr>
        <tr>
          <td>Date:</td>
          <td>{Profile.birthDate}</td>
        </tr>
        
      </tbody>
    </table>
      
    </div>
  );
};

export default ViewProfile;