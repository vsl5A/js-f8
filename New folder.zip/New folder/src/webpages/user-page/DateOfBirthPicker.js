import React, { useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
//  var Fafsdf = new Date();
//  Fafsdf.getDa
function DateOfBirthPicker() {
  const [selectedDate, setSelectedDate] = useState(new Date());

  const handleDateChange = (date) => {
    setSelectedDate(date);
    console.log(date)
  };

  return (
    <div >
      <label htmlFor="dob">Ngày sinh:</label>
      <DatePicker
        
        id="dob" 
        selected={selectedDate}
        onChange={handleDateChange}
        dateFormat="dd/MM/yyyy"
        showYearDropdown
        scrollableYearDropdown
        yearDropdownItemNumber={100}
        placeholderText="DD/MM/YYYY"
      />
    </div>
  );
}

export default DateOfBirthPicker;

